# @mwilliams/ui

Private, mobile-first React component library and website toolkit. Accessible by default, themed with CSS custom properties, router-agnostic, and compatible with React 18.3 and 19.

This package is private (`"private": true`) and is not published to any registry.

## Develop

Requires Node 22.12 or newer.

```sh
npm install
npm run storybook        # component showroom at http://localhost:6006
npm test                 # unit and accessibility tests
npm run lint && npm run typecheck
npm run build            # dist/ (ES modules, type declarations, CSS, precompiled CSS)
npm run verify:consumer  # builds a separate React 18.3 app against the packed library
npm run build-storybook && npm run test:e2e   # browser tests (run `npx playwright install chromium webkit firefox` once)
```

## Use in a project

Full walkthroughs are in Storybook under **Docs/Getting started** (Tailwind 4 apps) and **Docs/Plain CSS sites** (everything else). For a new client site, follow **Docs/Start a client site**: each site pins its own packed copy in its repository, so library changes never reach existing projects. Changes between versions are in [CHANGELOG.md](CHANGELOG.md). The short version:

```sh
# here: build and pack (the package is not on a registry yet)
npm ci && npm run build && npm pack
# in your app (React 18.3+)
mkdir -p vendor && cp ../component-library/mwilliams-ui-1.0.0.tgz vendor/
npm install ./vendor/mwilliams-ui-1.0.0.tgz
```

Tailwind 4 app, in the main CSS file:

```css
@import 'tailwindcss';
@import '@mwilliams/ui/styles.css';
@import '@mwilliams/ui/themes/warm.css'; /* optional: noir.css or warm.css */
```

Plain-CSS site: import the precompiled styles and render components inside an element with `class="ui"`:

```tsx
import '@mwilliams/ui/compiled.css';
import '@mwilliams/ui/themes/warm.css'; // after compiled.css
```

```html
<div id="contact" class="ui" data-theme="warm"></div>
```

Then use components and set the theme on `<html>` (or the `.ui` element):

```tsx
import { Button, Section, SectionHeading } from '@mwilliams/ui';

<Section>
  <SectionHeading eyebrow="Visit" title="Reservations and questions" />
  <Button href="/visit">Reserve a table</Button>
</Section>;
```

## Structure

```text
src/
  styles/     theme.css (Tailwind mapping), themes/*.css, components.css, base.css
  core/       Layer 1 building blocks, one folder per component (code, tests, stories)
  sections/   Layer 2 website sections, built from core
  forms/      useFormSubmit, HoneypotField, and one module per submission adapter
  seo/        Seo, JsonLd, and schema.org helpers
  hooks/  providers/  utils/
  docs/       Storybook docs: getting started, client sites, theming, motion, forms, SEO, decisions, sources
  stories/    demo content, five sample sites, the showroom (not built into the package)
e2e/          Playwright: story sweep, motion, navigation, no-JS forms, precompiled CSS isolation, cross-browser smoke
```

Rules enforced by lint: core never imports from sections; components use theme tokens, never literal or palette colors.
